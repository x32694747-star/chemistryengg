import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function startServer() {
  const app = express();
  const server = createServer(app);
  const io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Simple in-memory store for classroom sessions
  // In a production app, use Redis or Firestore
  const rooms = new Map<string, any>();

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('create-room', (data) => {
      const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const roomData = {
        id: roomCode,
        teacherId: socket.id,
        teacherName: data.teacherName,
        quizId: data.quizId,
        quizTitle: data.quizTitle,
        status: 'waiting', // waiting, active, finished
        students: [],
        currentQuestionIndex: 0,
        results: []
      };
      rooms.set(roomCode, roomData);
      socket.join(roomCode);
      socket.emit('room-created', roomData);
      console.log(`Room created: ${roomCode} by ${data.teacherName}`);
    });

    socket.on('join-room', (data) => {
      const room = rooms.get(data.roomCode);
      if (room) {
        if (room.status !== 'waiting') {
          socket.emit('error', { message: 'Exam already in progress or finished.' });
          return;
        }
        const student = {
          id: socket.id,
          name: data.studentName,
          score: 0,
          answers: []
        };
        room.students.push(student);
        socket.join(data.roomCode);
        socket.emit('joined-room', room);
        io.to(data.roomCode).emit('user-joined', { students: room.students });
        console.log(`Student ${data.studentName} joined room ${data.roomCode}`);
      } else {
        socket.emit('error', { message: 'Room not found.' });
      }
    });

    socket.on('start-exam', (roomCode) => {
      const room = rooms.get(roomCode);
      if (room && room.teacherId === socket.id) {
        room.status = 'active';
        io.to(roomCode).emit('exam-started', { room });
        console.log(`Exam started in room ${roomCode}`);
      }
    });

    socket.on('submit-answer', (data) => {
      const { roomCode, questionIndex, answer, isCorrect } = data;
      const room = rooms.get(roomCode);
      if (room) {
        const student = room.students.find((s: any) => s.id === socket.id);
        if (student) {
          student.answers[questionIndex] = { answer, isCorrect };
          if (isCorrect) student.score += 100;
          
          io.to(roomCode).emit('update-progress', { students: room.students });
        }
      }
    });

    socket.on('end-exam', (roomCode) => {
      const room = rooms.get(roomCode);
      if (room && room.teacherId === socket.id) {
        room.status = 'finished';
        io.to(roomCode).emit('exam-ended', { room });
        console.log(`Exam ended in room ${roomCode}`);
      }
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
      // Clean up empty rooms or mark teacher offline if needed
      // For now, keep simple
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
