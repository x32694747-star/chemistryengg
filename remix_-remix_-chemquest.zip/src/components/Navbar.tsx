import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FlaskConical, 
  Menu, 
  X, 
  User, 
  LogOut, 
  Trophy, 
  Sun, 
  Moon,
  ChevronDown,
  LayoutDashboard,
  Brain,
  BookOpen,
  Info,
  Gamepad2,
  Presentation
} from 'lucide-react';
import { signOut } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { View } from '../App';

interface NavbarProps {
  currentView: View;
  onViewChange: (view: View) => void;
  user: any;
}

export function Navbar({ currentView, onViewChange, user }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    setIsDark(!isDark);
    if (!isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const navItems = [
    { id: 'games', label: 'Games', icon: Gamepad2 },
    { id: 'classroom', label: 'Classroom', icon: Presentation },
    { id: 'quizzes', label: 'Quizzes', icon: Brain },
    { id: 'problems', label: 'Problems', icon: LayoutDashboard },
    { id: 'notes', label: 'Notes', icon: BookOpen },
    { id: 'leaderboard', label: 'Rankings', icon: Trophy },
  ] as const;

  const handleLogout = async () => {
    await signOut(auth);
    setShowUserMenu(false);
    onViewChange('home');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-600 to-blue-500 border-b border-blue-400/30">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => onViewChange('home')}
          >
            <div className="bg-white text-blue-600 p-1.5 rounded-lg shadow-sm group-hover:scale-105 transition-transform">
              <FlaskConical className="w-6 h-6" strokeWidth={2.5} />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">ChemQuest</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id as View)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentView === item.id 
                    ? 'bg-white/20 text-white' 
                    : 'text-blue-100 hover:bg-white/10'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          {/* Right Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-blue-400/20 text-white hover:bg-blue-400/30 transition-colors"
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-3 text-white group"
                >
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] opacity-70 font-bold uppercase tracking-widest">Chemistry Scholar</p>
                    <p className="text-sm font-semibold">{user.displayName || 'Learner'}</p>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-blue-400 border-2 border-white flex items-center justify-center font-bold shadow-sm">
                    {user.displayName?.[0] || 'U'}
                  </div>
                </button>

                <AnimatePresence>
                  {showUserMenu && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-3 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden"
                    >
                      <div className="p-4 border-b border-slate-100 dark:border-slate-800">
                        <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Authenticated as</p>
                        <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{user.email}</p>
                      </div>
                      <div className="p-2">
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center space-x-3 px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition font-bold text-sm"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <button
                onClick={() => onViewChange('auth')}
                className="px-8 py-3 bg-slate-900 dark:bg-blue-600 text-white rounded-2xl font-bold text-sm hover:bg-slate-800 dark:hover:bg-blue-700 transition shadow-xl shadow-slate-200 dark:shadow-none underline-none"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Toggle */}
          <div className="lg:hidden flex items-center space-x-3">
             <button onClick={toggleTheme} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-900">
               {isDark ? <Sun className="w-5 h-5 text-slate-600" /> : <Moon className="w-5 h-5 text-slate-600" />}
             </button>
             <button 
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-slate-900 dark:text-white"
            >
              {isOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 overflow-hidden"
          >
            <div className="p-6 space-y-3">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id as View);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center space-x-4 p-4 rounded-2xl font-bold transition-all ${
                    currentView === item.id 
                    ? 'bg-blue-600 text-white' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              ))}
              {!user && (
                <button
                  onClick={() => {
                    onViewChange('auth');
                    setIsOpen(false);
                  }}
                  className="w-full py-4 bg-slate-900 dark:bg-blue-600 text-white rounded-2xl font-black mt-4"
                >
                  Sign In
                </button>
              )}
              {user && (
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-4 p-4 text-red-500 font-bold"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Sign Out</span>
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
