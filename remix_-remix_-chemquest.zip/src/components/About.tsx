import React from 'react';
import { Info, Mail, Github, Twitter, ExternalLink, Heart, Shield, Award } from 'lucide-react';

export function About() {
  return (
    <div className="max-w-4xl mx-auto space-y-16 py-12">
      <section className="text-center space-y-6">
        <div className="inline-flex p-3 bg-blue-100 rounded-3xl text-blue-600 mb-2">
          <Info className="w-8 h-8" />
        </div>
        <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight">About ChemQuest</h2>
        <p className="text-xl text-slate-600 leading-relaxed max-w-2xl mx-auto">
          We are dedicated to building a modern, accessible learning environment for university chemistry students worldwide.
        </p>
      </section>

      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold flex items-center space-x-2 text-slate-900 border-l-4 border-blue-600 pl-4">
               <span>Our Mission</span>
            </h3>
            <p className="text-slate-600 leading-relaxed">
              Chemistry can be daunting. Our goal is to break down complex theories into manageable, interactive components. 
              By merging gamified quizzes with step-by-step problem solving, we help students build intuition and confidence in their scientific journey.
            </p>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-2xl font-bold flex items-center space-x-2 text-slate-900 border-l-4 border-indigo-600 pl-4">
               <span>Core Values</span>
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <ValueItem icon={<Shield className="w-5 h-5" />} title="Accuracy" desc="Content verified by experts." />
              <ValueItem icon={<Heart className="w-5 h-5" />} title="Accessibility" desc="Free for all students." />
              <ValueItem icon={<Award className="w-5 h-5" />} title="Excellence" desc="Designed for top exam ranks." />
              <ValueItem icon={<ExternalLink className="w-5 h-5" />} title="Growth" desc="Continuous updates." />
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-10 rounded-[3rem] text-white space-y-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl -mr-16 -mt-16"></div>
          <h3 className="text-2xl font-bold">Contact & Support</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Have questions? Want to contribute notes or report a bug? We'd love to hear from you.
          </p>
          
          <div className="space-y-3">
            <ContactLink icon={<Mail className="w-4 h-4" />} label="support@chemquest.edu" />
            <ContactLink icon={<Twitter className="w-4 h-4" />} label="@ChemQuestEdu" />
            <ContactLink icon={<Github className="w-4 h-4" />} label="ChemQuest-Community" />
          </div>

          <div className="pt-6 border-t border-slate-800 flex justify-between items-center text-[10px] text-slate-500 uppercase tracking-widest font-black">
             <span>v1.0.4 Release</span>
             <span>© 2026</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function ValueItem({ icon, title, desc }: any) {
  return (
    <div className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
      <div className="text-blue-600 mb-2">{icon}</div>
      <h5 className="font-bold text-slate-900 text-sm">{title}</h5>
      <p className="text-slate-500 text-xs leading-tight mt-1">{desc}</p>
    </div>
  );
}

function ContactLink({ icon, label }: any) {
  return (
    <a href="#" className="flex items-center space-x-3 text-slate-300 hover:text-white transition-colors bg-white/5 p-4 rounded-xl border border-white/5 hover:border-white/20">
      {icon}
      <span className="font-medium text-sm">{label}</span>
    </a>
  );
}
