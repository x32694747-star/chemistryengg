import React from 'react';
import { motion } from 'motion/react';
import { Gamepad2, FlaskConical, Boxes, Brain, ChevronRight, Zap } from 'lucide-react';
import { View } from '../App';

interface GamesProps {
  onViewChange: (view: View) => void;
}

export function Games({ onViewChange }: GamesProps) {
  const games = [
    {
      id: 'matcher',
      title: 'Ketone Crush',
      description: 'Match organic functional groups to their names in this fast-paced chemistry puzzle.',
      icon: <Boxes className="w-12 h-12 text-pink-500" />,
      color: 'pink',
      difficulty: 'Medium',
      points: '100 pts'
    },
    {
      id: 'predictor',
      title: 'Reaction Lab',
      description: 'Powered by Gemini AI. Enter reactants and predict products with chemical accuracy.',
      icon: <FlaskConical className="w-12 h-12 text-blue-500" />,
      color: 'blue',
      difficulty: 'Hard',
      points: 'AI Feature'
    },
    {
      id: 'memory',
      title: 'Element Memory',
      description: 'Master the periodic table by matching symbols to names in this classic brain teaser.',
      icon: <Brain className="w-12 h-12 text-emerald-500" />,
      color: 'emerald',
      difficulty: 'Easy',
      points: '50 pts'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-12 py-10">
      <div className="text-center space-y-4">
        <motion.div
           initial={{ y: -20, opacity: 0 }}
           animate={{ y: 0, opacity: 1 }}
           className="inline-flex items-center space-x-2 bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 px-4 py-1.5 rounded-full text-sm font-bold border border-indigo-100 dark:border-indigo-900"
        >
          <Gamepad2 className="w-4 h-4" />
          <span>Chemistry Gaming Zone</span>
        </motion.div>
        <h2 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
          Learn through <span className="text-indigo-600 dark:text-indigo-400">Play</span>
        </h2>
        <p className="max-w-2xl mx-auto text-lg text-slate-600 dark:text-slate-400 font-medium">
          Interactive games designed to make complex concepts intuitive and memorable. 
          Challenge yourself and climb the leaderboard.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {games.map((game, idx) => (
          <motion.div
            key={game.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ y: -10, scale: 1.02 }}
            onClick={() => onViewChange(game.id as View)}
            className="group cursor-pointer bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2.5rem] p-8 shadow-xl hover:shadow-2xl transition-all relative overflow-hidden"
          >
            <div className={`absolute top-0 right-0 w-32 h-32 bg-${game.color}-500/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-${game.color}-500/20 transition-colors`}></div>
            
            <div className="space-y-6 relative z-10">
              <div className={`w-20 h-20 bg-${game.color}-50 dark:bg-${game.color}-900/20 rounded-3xl flex items-center justify-center transition-transform group-hover:rotate-12`}>
                {game.icon}
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-black uppercase tracking-widest text-${game.color}-600 dark:text-${game.color}-400`}>{game.difficulty}</span>
                  <span className="text-xs font-bold text-slate-400">{game.points}</span>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">{game.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed font-medium">
                  {game.description}
                </p>
              </div>

              <div className={`flex items-center space-x-2 text-${game.color}-600 dark:text-${game.color}-400 font-bold text-sm pt-4 border-t border-slate-100 dark:border-slate-800`}>
                <span>Play Game</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Stats Board */}
      <section className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-48 -mt-48"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
          <div className="space-y-4">
            <h3 className="text-3xl font-bold">Gaming Rewards</h3>
            <p className="text-indigo-100 max-w-md font-medium">
              Every game session contributes to your global rank. Earn double points on weekends and unlock exclusive badges.
            </p>
            <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-4">
               {[ 'Combo Multiplier', 'Quick Reflexes', 'AI Explorer' ].map(badge => (
                 <div key={badge} className="px-4 py-2 bg-white/10 backdrop-blur border border-white/20 rounded-xl text-xs font-bold font-mono">
                   {badge}
                 </div>
               ))}
            </div>
          </div>
          <div className="flex gap-4">
            <div className="bg-white/10 backdrop-blur p-8 rounded-3xl border border-white/20 text-center min-w-[140px]">
              <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-3xl font-black">2.5x</div>
              <div className="text-[10px] uppercase tracking-widest opacity-60">Avg Boost</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
