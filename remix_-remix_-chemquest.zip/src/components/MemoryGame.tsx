import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, 
  RotateCcw, 
  ChevronLeft, 
  Trophy, 
  Timer, 
  Star,
  CheckCircle2,
  Atom
} from 'lucide-react';

interface MemoryGameProps {
  user: any;
  onBack: () => void;
}

const ELEMENTS = [
  { symbol: 'H', name: 'Hydrogen' },
  { symbol: 'He', name: 'Helium' },
  { symbol: 'Li', name: 'Lithium' },
  { symbol: 'Be', name: 'Beryllium' },
  { symbol: 'B', name: 'Boron' },
  { symbol: 'C', name: 'Carbon' },
  { symbol: 'N', name: 'Nitrogen' },
  { symbol: 'O', name: 'Oxygen' },
  { symbol: 'F', name: 'Fluorine' },
  { symbol: 'Ne', name: 'Neon' },
  { symbol: 'Na', name: 'Sodium' },
  { symbol: 'Mg', name: 'Magnesium' },
  { symbol: 'Al', name: 'Aluminum' },
  { symbol: 'Si', name: 'Silicon' },
  { symbol: 'P', name: 'Phosphorus' },
  { symbol: 'S', name: 'Sulfur' },
];

export function MemoryGame({ user, onBack }: MemoryGameProps) {
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [time, setTime] = useState(0);
  const [isWon, setIsWon] = useState(false);
  const [isStarted, setIsStarted] = useState(false);

  const initGame = () => {
    // Pick 8 random elements
    const selected = [...ELEMENTS].sort(() => 0.5 - Math.random()).slice(0, 8);
    
    // Create pairs (one card has symbol, one has name)
    const cardPairs = selected.flatMap((el, idx) => [
      { id: idx * 2, value: el.symbol, pairId: idx, type: 'symbol' },
      { id: idx * 2 + 1, value: el.name, pairId: idx, type: 'name' }
    ]);
    
    setCards(cardPairs.sort(() => 0.5 - Math.random()));
    setFlipped([]);
    setMatched([]);
    setMoves(0);
    setTime(0);
    setIsWon(false);
    setIsStarted(true);
  };

  useEffect(() => {
    let timer: any;
    if (isStarted && !isWon) {
      timer = setInterval(() => setTime(t => t + 1), 1000);
    }
    return () => clearInterval(timer);
  }, [isStarted, isWon]);

  const handleFlip = (id: number) => {
    if (flipped.length === 2 || flipped.includes(id) || matched.includes(id)) return;

    const newFlipped = [...flipped, id];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(m => m + 1);
      const [first, second] = newFlipped;
      if (cards[first].pairId === cards[second].pairId) {
        setMatched(prev => [...prev, first, second]);
        setFlipped([]);
        if (matched.length + 2 === cards.length) {
          setIsWon(true);
        }
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-emerald-600 transition shadow-sm"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white flex items-center space-x-3">
            <Brain className="w-8 h-8 text-emerald-600" />
            <span>Element Memory</span>
          </h2>
        </div>

        {isStarted && (
           <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-white dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 font-bold text-sm">
                <Timer className="w-4 h-4 text-emerald-500" />
                <span>{Math.floor(time / 60)}:{(time % 60).toString().padStart(2, '0')}</span>
              </div>
              <div className="flex items-center space-x-2 bg-white dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 font-bold text-sm">
                <Star className="w-4 h-4 text-blue-500" />
                <span>Moves: {moves}</span>
              </div>
           </div>
        )}
      </div>

      {!isStarted ? (
        <div className="bg-white dark:bg-slate-900 p-12 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-8">
           <div className="w-24 h-24 bg-emerald-50 dark:bg-emerald-900/30 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-inner">
             <Atom className="w-12 h-12 text-emerald-600" />
           </div>
           <div className="space-y-4">
             <h3 className="text-2xl font-bold dark:text-white">Master the Periodic Table</h3>
             <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto font-medium">
               Match essential element symbols with their full names. Improve your chemical recall speed.
             </p>
           </div>
           <button
             onClick={initGame}
             className="px-12 py-5 bg-emerald-600 text-white rounded-3xl font-black text-xl hover:bg-emerald-700 transition shadow-xl shadow-emerald-100 dark:shadow-none"
           >
             Start Training
           </button>
        </div>
      ) : isWon ? (
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="bg-white dark:bg-slate-900 p-12 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-8"
        >
           <Trophy className="w-20 h-20 text-yellow-400 mx-auto" />
           <div className="space-y-2">
             <h2 className="text-4xl font-black text-slate-900 dark:text-white">Fantastic Recall!</h2>
             <p className="text-slate-500 font-medium">You completed the grid in {moves} moves.</p>
           </div>
           <div className="flex justify-center gap-4">
              <button
                onClick={initGame}
                className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center space-x-2 hover:bg-emerald-700 transition shadow-lg"
              >
                <RotateCcw className="w-5 h-5" />
                <span>Play Again</span>
              </button>
           </div>
        </motion.div>
      ) : (
        <div className="grid grid-cols-4 gap-4">
          {cards.map((card, idx) => (
            <div key={card.id} className="aspect-square perspective-1000">
               <motion.div
                 className={`w-full h-full relative preserve-3d transition-transform duration-500 cursor-pointer`}
                 initial={false}
                 animate={{ rotateY: matched.includes(idx) || flipped.includes(idx) ? 180 : 0 }}
                 onClick={() => handleFlip(idx)}
               >
                 {/* Back of Card */}
                 <div className="absolute inset-0 backface-hidden bg-slate-900 dark:bg-slate-800 rounded-2xl flex items-center justify-center border-2 border-slate-700 overflow-hidden group">
                    <div className="absolute inset-0 bg-blue-600/5 group-hover:bg-blue-600/20 transition-colors"></div>
                    <Atom className="w-8 h-8 text-slate-600 group-hover:text-blue-500 transition-colors" />
                 </div>

                 {/* Front of Card */}
                 <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-900 rounded-2xl flex items-center justify-center border-2 border-emerald-500/30 rotateY-180 shadow-lg">
                    <div className="text-center px-2">
                      <span className={`font-black tracking-tight dark:text-white ${card.type === 'symbol' ? 'text-4xl text-blue-600' : 'text-sm text-slate-600'}`}>
                        {card.value}
                      </span>
                    </div>
                    {matched.includes(idx) && (
                      <div className="absolute top-2 right-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      </div>
                    )}
                 </div>
               </motion.div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
