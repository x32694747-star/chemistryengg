import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Beaker, Lightbulb, CheckCircle, FileQuestion, ArrowRight } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, updateStats, handleFirestoreError } from '../lib/firebase';
import problemsData from '../data/problems.json';

interface ProblemsProps {
  user: any;
}

export function Problems({ user }: ProblemsProps) {
  const [selectedTopic, setSelectedTopic] = useState('All');
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [showHints, setShowHints] = useState<Record<string, boolean>>({});
  const [showSolution, setShowSolution] = useState<Record<string, boolean>>({});
  const [verified, setVerified] = useState<Record<string, boolean | null>>({});

  const topics = ['All', ...new Set(problemsData.map(p => p.topic))];

  const checkAnswer = async (problemId: string, correctAnswer: string, topic: string) => {
    const isCorrect = userAnswers[problemId]?.trim() === correctAnswer.trim();
    setVerified(prev => ({ ...prev, [problemId]: isCorrect }));
    
    if (isCorrect && user) {
      try {
        await addDoc(collection(db, 'users', user.uid, 'problemAttempts'), {
           userId: user.uid,
           problemId,
           topic,
           solved: true,
           hintsUsed: showHints[problemId] ? 1 : 0, 
           completedAt: serverTimestamp()
        }).catch(e => handleFirestoreError(e, 'create', `users/${user.uid}/problemAttempts`));
        
        await updateStats(user.uid, 50, false); 
      } catch (err) {
        console.error("Failed to save problem attempt:", err);
      }
    }
  };

  const toggleHint = (id: string) => {
    setShowHints(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleSolution = (id: string) => {
    setShowSolution(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredProblems = selectedTopic === 'All' 
    ? problemsData 
    : problemsData.filter(p => p.topic === selectedTopic);

  return (
    <div className="max-w-5xl mx-auto space-y-12 py-10">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white">Numerical Problem Solver</h2>
        <p className="text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
          Practice complex numerical problems with step-by-step guidance. Use hints if you're stuck and reveal the full solution to verify your work.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        {topics.map(t => (
          <button
            key={t}
            onClick={() => setSelectedTopic(t)}
            className={`px-5 py-2 rounded-full text-sm font-semibold transition-all ${
              selectedTopic === t 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-100' 
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="grid gap-10">
        {filteredProblems.map((problem) => (
          <motion.div
            layout
            key={problem.id}
            className="bg-white dark:bg-slate-900 rounded-2xl border border-[#F3F4F6] dark:border-slate-800 shadow-vibrant overflow-hidden flex flex-col md:flex-row"
          >
            <div className="w-full md:w-48 bg-slate-50 dark:bg-slate-800/50 p-8 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-[#F3F4F6] dark:border-slate-800 text-center">
              <div className="bg-blue-100 dark:bg-blue-900/30 p-4 rounded-xl text-blue-600 dark:text-blue-400 mb-4 shadow-inner">
                <Beaker className="w-8 h-8" />
              </div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">{problem.topic}</span>
              <h4 className="text-slate-900 dark:text-white font-bold leading-tight tracking-tight">{problem.title}</h4>
            </div>

            <div className="flex-1 p-8 md:p-10 space-y-8">
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 font-bold italic">
                  <FileQuestion className="w-5 h-5 flex-shrink-0" />
                  <span>Problem Statement</span>
                </div>
                <p className="text-lg md:text-xl text-slate-800 dark:text-white leading-relaxed font-medium">
                  {problem.description}
                </p>
              </div>

              <div className="bg-[#F0F7FF] dark:bg-slate-800/30 p-6 rounded-2xl border border-[#DBEAFE] dark:border-slate-800 flex flex-col md:flex-row items-center gap-4">
                <div className="relative flex-1 w-full">
                   <input 
                     type="text" 
                     placeholder="Enter numerical answer..."
                     className={`w-full px-6 py-4 bg-white dark:bg-slate-900 border-2 rounded-xl outline-none transition-all ${
                        verified[problem.id] === true ? 'border-emerald-500' : 
                        verified[problem.id] === false ? 'border-red-400' : 'border-slate-100 dark:border-slate-700 dark:text-white focus:border-blue-500'
                     }`}
                     value={userAnswers[problem.id] || ''}
                     onChange={(e) => setUserAnswers(prev => ({ ...prev, [problem.id]: e.target.value }))}
                   />
                   {verified[problem.id] === true && (
                     <CheckCircle className="w-6 h-6 text-emerald-500 absolute right-4 top-1/2 -translate-y-1/2" />
                   )}
                </div>
                <button
                  onClick={() => checkAnswer(problem.id, problem.answer, problem.topic)}
                  className="w-full md:w-auto px-8 py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-100 dark:shadow-none"
                >
                  Verify
                </button>
              </div>

              <div className="flex flex-wrap gap-4 pt-2">
                <button
                  onClick={() => toggleHint(problem.id)}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                    showHints[problem.id] ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Lightbulb className="w-4 h-4" />
                  <span>{showHints[problem.id] ? 'Hide Hints' : 'Need a Hint?'}</span>
                </button>
                <button
                   onClick={() => toggleSolution(problem.id)}
                   className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                    showSolution[problem.id] ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border border-blue-200 dark:border-blue-800' : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>{showSolution[problem.id] ? 'Hide Solution' : 'View Full Solution'}</span>
                </button>
              </div>

              <AnimatePresence>
                {showHints[problem.id] && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-amber-50 dark:bg-amber-900/10 rounded-2.5xl p-8 border border-amber-100 dark:border-amber-900/30 space-y-4">
                      <h5 className="font-black uppercase tracking-widest text-xs text-amber-600 dark:text-amber-400 flex items-center space-x-2">
                        <Lightbulb className="w-4 h-4" />
                        <span>Available Hints</span>
                      </h5>
                      <ul className="space-y-4">
                        {problem.hints.map((hint, idx) => (
                          <li key={idx} className="flex items-start space-x-3 text-amber-800 dark:text-amber-200 text-sm">
                            <span className="w-5 h-5 rounded-lg bg-amber-200/50 dark:bg-amber-800/50 flex flex-shrink-0 items-center justify-center font-bold font-sans">{idx + 1}</span>
                            <p>{hint}</p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {showSolution[problem.id] && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-blue-50/50 dark:bg-blue-900/10 rounded-2.5xl p-8 border border-blue-100 dark:border-blue-900/30 space-y-4">
                      <h5 className="font-black uppercase tracking-widest text-xs text-blue-600 dark:text-blue-400 flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4" />
                        <span>Step-by-Step Solution</span>
                      </h5>
                      <div className="space-y-6">
                        {problem.solution.map((step, idx) => (
                          <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-blue-100 dark:border-blue-900 shadow-sm">
                             <p className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">{step}</p>
                          </div>
                        ))}
                        <div className="bg-blue-600 text-white p-6 rounded-2xl text-center">
                           <span className="text-xs uppercase tracking-widest opacity-70 font-bold mb-1 block">Final Result</span>
                           <span className="text-2xl font-black">{problem.answer}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
