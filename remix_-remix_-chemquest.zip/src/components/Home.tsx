import React from 'react';
import { motion } from 'motion/react';
import { Brain, CheckCircle, BookOpen, ChevronRight, Zap, Target, BookMarked, Gamepad2 } from 'lucide-react';
import { View } from '../App';

interface HomeProps {
  onViewChange: (view: View) => void;
}

export function Home({ onViewChange }: HomeProps) {
  return (
    <div className="max-w-6xl mx-auto space-y-20 py-10 relative">
      {/* Background Blobs */}
      <div className="absolute top-0 -left-10 w-72 h-72 bg-blue-400/10 rounded-full blur-3xl -z-10 animate-pulse"></div>
      <div className="absolute top-20 -right-20 w-96 h-96 bg-purple-400/10 rounded-full blur-3xl -z-10 animate-pulse" style={{ animationDelay: '1s' }}></div>

      {/* Hero Section */}
      <section className="text-center space-y-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center space-x-2 bg-blue-50 text-blue-600 px-4 py-1.5 rounded-full text-sm font-semibold border border-blue-100"
        >
          <Zap className="w-4 h-4 fill-current" />
          <span>Master Chemistry the Smart Way</span>
        </motion.div>
        
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-tight">
          Level up your <span className="text-blue-600 dark:text-blue-400">Chemistry</span> knowledge.
        </h1>
        
        <p className="max-w-2xl mx-auto text-xl text-slate-600 dark:text-slate-400 leading-relaxed">
          The ultimate platform for college students to practice quizzes, solve numerical problems, 
          and access concise revision notes for exam preparation.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <button
            onClick={() => onViewChange('games')}
            className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition shadow-xl shadow-indigo-200 dark:shadow-indigo-900/20 flex items-center justify-center space-x-2"
          >
            <Gamepad2 className="w-5 h-5" />
            <span>Play Games</span>
          </button>
          <button
            onClick={() => onViewChange('quizzes')}
            className="w-full sm:w-auto px-8 py-4 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-2xl font-bold text-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition flex items-center justify-center space-x-2"
          >
            <span>Start Practice</span>
          </button>
        </div>
      </section>

      {/* Feature Cards */}
      <section className="grid md:grid-cols-4 gap-6">
        <FeatureCard 
          icon={<Gamepad2 className="w-10 h-10 text-indigo-500" />}
          title="Chemistry Games"
          description="Interactive puzzles like Ketone Crush and AI reaction prediction."
          onClick={() => onViewChange('games')}
          color="indigo"
        />
        <FeatureCard 
          icon={<CheckCircle className="w-10 h-10 text-emerald-500" />}
          title="Interactive Quizzes"
          description="Multiple choice questions categorized by Physical, Organic, and Inorganic Chemistry with instant feedback."
          onClick={() => onViewChange('quizzes')}
          color="emerald"
        />
        <FeatureCard 
          icon={<Brain className="w-10 h-10 text-blue-500" />}
          title="Problem Solving"
          description="Step-by-step numerical solutions for thermodynamics, kinetics, water tech, and more."
          onClick={() => onViewChange('problems')}
          color="blue"
        />
        <FeatureCard 
          icon={<BookMarked className="w-10 h-10 text-amber-500" />}
          title="Revision Notes"
          description="Concise notes, important formulas, and quick reference guides for all major topics."
          onClick={() => onViewChange('notes')}
          color="amber"
        />
      </section>

      {/* Stats/Info Section */}
      <section className="bg-slate-900 dark:bg-slate-900 rounded-[2.5rem] p-12 text-white overflow-hidden relative border border-slate-800">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/20 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/20 rounded-full blur-3xl -ml-32 -mb-32"></div>
        
        <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">Why choose ChemQuest?</h2>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <div className="mt-1 p-1 bg-blue-500/20 rounded text-blue-400">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold">Focused Curriculum</h4>
                  <p className="text-slate-400 text-sm">Content specifically designed for college-level exams and MCQ patterns.</p>
                </div>
              </li>
              <li className="flex items-start space-x-3">
                <div className="mt-1 p-1 bg-blue-500/20 rounded text-blue-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold">Progress Tracking</h4>
                  <p className="text-slate-400 text-sm">Monitor your scores and identify weak areas with personalized progress reports.</p>
                </div>
              </li>
            </ul>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <StatCard label="Quizzes Available" value="500+" />
            <StatCard label="Daily Active Students" value="2k+" />
            <StatCard label="Topics Covered" value="45+" />
            <StatCard label="Exams Prepared For" value="12+" />
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description, onClick, color }: any) {
  const colorMap: any = {
    emerald: 'hover:border-emerald-200 dark:hover:border-emerald-800 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 text-emerald-600',
    blue: 'hover:border-blue-200 dark:hover:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/10 text-blue-600',
    amber: 'hover:border-amber-200 dark:hover:border-amber-800 hover:bg-amber-50 dark:hover:bg-amber-900/10 text-amber-600',
    indigo: 'hover:border-indigo-200 dark:hover:border-indigo-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 text-indigo-600',
  };

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      onClick={onClick}
      className={`p-10 glass-card rounded-2xl cursor-pointer transition-all ${colorMap[color]}`}
    >
      <div className="mb-6">{icon}</div>
      <h3 className="text-2xl font-bold text-slate-800 dark:text-white mb-3 tracking-tight">{title}</h3>
      <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium">{description}</p>
    </motion.div>
  );
}

function StatCard({ label, value }: { label: string, value: string }) {
  return (
    <div className="glass-card p-6 rounded-2xl text-center">
      <div className="text-3xl font-bold text-blue-400 mb-1">{value}</div>
      <div className="text-xs uppercase tracking-widest text-slate-500 font-bold">{label}</div>
    </div>
  );
}
