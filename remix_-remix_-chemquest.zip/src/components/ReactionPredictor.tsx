import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FlaskConical, 
  ArrowRight, 
  Cpu, 
  Beaker, 
  AlertCircle, 
  CheckCircle2, 
  RotateCcw,
  Sparkles,
  ChevronLeft,
  Loader2
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface ReactionPredictorProps {
  user: any;
  onBack: () => void;
}

export function ReactionPredictor({ user, onBack }: ReactionPredictorProps) {
  const [reactants, setReactants] = useState('');
  const [isPredicting, setIsPredicting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const predictReaction = async () => {
    if (!reactants.trim()) return;

    setIsPredicting(true);
    setError(null);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });
      const prompt = `Predict the products and conditions for the following chemical reaction: ${reactants}. 
      Give the output in a clear JSON format with the following keys:
      - products: string representing the chemical products
      - balancedEquation: the full balanced chemical equation
      - conditions: string representing temperature, catalyst, pressure, etc.
      - explanation: a brief 2-3 sentence theoretical explanation
      - type: the type of reaction (e.g. Substitution, Elimination, Redox)
      - safetyIndices: any safety warnings (Corrosive, Flammable, etc)`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "You are an expert chemical reaction predictor. Provide accurate, safety-conscious chemical predictions. Format all responses as valid JSON.",
          responseMimeType: "application/json"
        }
      });

      if (response && response.text) {
        const parsed = JSON.parse(response.text);
        setResult(parsed);
      } else {
        throw new Error("Empty response from AI");
      }
    } catch (err: any) {
      console.error("AI Prediction failed:", err);
      setError("Failed to predict reaction. Please ensure the reactants are written correctly.");
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 py-6">
      <div className="flex items-center space-x-4">
        <button 
          onClick={onBack}
          className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-blue-600 transition shadow-sm"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white flex items-center space-x-2">
            <Cpu className="w-8 h-8 text-blue-600" />
            <span>AI Reaction Lab</span>
          </h2>
          <p className="text-slate-500 font-medium">Next-generation chemical prediction powered by Gemini</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Input Panel */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl space-y-6">
            <div className="flex items-center space-x-2 text-blue-600 font-bold uppercase tracking-widest text-xs">
              <Beaker className="w-4 h-4" />
              <span>Experiment Input</span>
            </div>
            
            <div className="space-y-4">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">Enter Reactants (e.g. "NaCl + AgNO3")</label>
              <textarea
                value={reactants}
                onChange={(e) => setReactants(e.target.value)}
                placeholder="Type reactants or describe the reaction..."
                className="w-full h-40 p-6 bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-3xl outline-none focus:border-blue-500 dark:focus:border-blue-600 transition-all text-lg font-medium dark:text-white"
              />
            </div>

            <button
              onClick={predictReaction}
              disabled={isPredicting || !reactants.trim()}
              className="w-full py-5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl font-bold text-lg shadow-lg shadow-blue-100 dark:shadow-none hover:translate-y-[-2px] hover:shadow-xl transition-all disabled:opacity-50 disabled:translate-y-0 flex items-center justify-center space-x-3"
            >
              {isPredicting ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>Synthesizing Prediction...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-6 h-6" />
                  <span>Predict Outcome</span>
                </>
              )}
            </button>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/10 p-6 rounded-3xl border border-blue-100 dark:border-blue-900/30 flex items-start space-x-4">
            <AlertCircle className="w-6 h-6 text-blue-600 shrink-0 mt-1" />
            <div className="text-sm text-blue-800 dark:text-blue-200">
              <p className="font-bold mb-1">Safety Note</p>
              <p className="opacity-80">This tool uses AI simulation. Always consult standard safety data sheets (SDS) and physical lab manuals before conducting real experiments.</p>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="relative min-h-[500px]">
          <AnimatePresence mode="wait">
            {!result && !isPredicting && !error && (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center p-12 text-center space-y-6 bg-slate-50/50 dark:bg-slate-800/20 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-[3rem]"
              >
                <div className="w-20 h-20 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center shadow-inner">
                  <FlaskConical className="w-10 h-10 text-slate-300" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-slate-400">Waiting for Reaction</h4>
                  <p className="text-slate-400 text-sm max-w-xs mx-auto">Enter your reactants on the left to start the AI molecular simulation.</p>
                </div>
              </motion.div>
            )}

            {isPredicting && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-white dark:bg-slate-900/50 backdrop-blur-sm rounded-[3rem] z-10"
                >
                  <div className="relative">
                    <div className="w-24 h-24 border-4 border-blue-100 dark:border-slate-800 rounded-full"></div>
                    <div className="w-24 h-24 border-4 border-blue-600 border-t-transparent rounded-full animate-spin absolute top-0 left-0"></div>
                  </div>
                  <p className="mt-6 text-blue-600 font-black animate-pulse uppercase tracking-widest text-sm">Processing Atoms...</p>
                </motion.div>
            )}

            {error && (
              <motion.div
                key="error"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 dark:bg-red-900/10 border-2 border-red-100 dark:border-red-900/30 p-12 rounded-[3rem] text-center space-y-4"
              >
                <AlertCircle className="w-16 h-16 text-red-500 mx-auto" />
                <h3 className="text-2xl font-bold text-red-700 dark:text-red-400">Prediction Error</h3>
                <p className="text-red-600 dark:text-red-300">{error}</p>
                <button 
                  onClick={() => setError(null)}
                  className="px-6 py-2 bg-red-100 text-red-700 rounded-xl font-bold hover:bg-red-200 transition"
                >
                  Clear & Retry
                </button>
              </motion.div>
            )}

            {result && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="bg-white dark:bg-primary-950 p-8 rounded-[2.5rem] border border-blue-100 dark:border-blue-900/50 shadow-2xl shadow-blue-100 dark:shadow-none space-y-8">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300 rounded-full text-[10px] font-black uppercase tracking-widest">
                        {result.type}
                      </span>
                      <h4 className="text-2xl font-black text-slate-900 dark:text-white">Predicted Outcome</h4>
                    </div>
                    <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                  </div>

                  <div className="space-y-4">
                    <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Balanced Equation</p>
                      <p className="text-xl md:text-2xl font-mono text-blue-600 dark:text-blue-400 font-bold overflow-x-auto whitespace-nowrap pb-2">
                        {result.balancedEquation}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-5 bg-amber-50 dark:bg-amber-900/10 rounded-2xl border border-amber-100 dark:border-amber-900/30">
                        <p className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-1">Conditions</p>
                        <p className="text-sm font-semibold dark:text-white">{result.conditions}</p>
                      </div>
                      <div className="p-5 bg-rose-50 dark:bg-rose-900/10 rounded-2xl border border-rose-100 dark:border-rose-900/30">
                        <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-widest mb-1">Safety Tags</p>
                        <p className="text-sm font-semibold dark:text-white">{result.safetyIndices}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h5 className="font-bold text-slate-900 dark:text-white flex items-center space-x-2">
                      <ArrowRight className="w-4 h-4 text-blue-600" />
                      <span>Theoretical Basis</span>
                    </h5>
                    <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed font-medium">
                      {result.explanation}
                    </p>
                  </div>

                  <button
                    onClick={() => setResult(null)}
                    className="w-full flex items-center justify-center space-x-2 py-4 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-slate-400 font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Test Another Batch</span>
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
