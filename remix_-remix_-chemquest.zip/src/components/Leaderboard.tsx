import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Trophy, Medal, Crown, ArrowUp, Loader2 } from 'lucide-react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db, isConfigured } from '../lib/firebase';

export function Leaderboard() {
  const [leaders, setLeaders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isConfigured) {
      // Mock data for demo/offline mode
      setLeaders([
        { id: '1', displayName: 'Curie', totalScore: 12500 },
        { id: '2', displayName: 'Lavoisier', totalScore: 11200 },
        { id: '3', displayName: 'Mendeleev', totalScore: 9800 },
        { id: '4', displayName: 'Dalton', totalScore: 8500 },
        { id: '5', displayName: 'Pauling', totalScore: 7200 }
      ]);
      setLoading(false);
      return;
    }

    const q = query(collection(db, 'leaderboard'), orderBy('totalScore', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setLeaders(docs);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
        <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Fetching Global Rankings...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-10 py-6">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-slate-900 dark:text-white">ChemQuest Hall of Fame</h2>
        <p className="text-slate-600 dark:text-slate-400">Join the elite ranks of chemistry scholars from around the globe.</p>
      </div>

      {/* Top 3 Summary */}
      <div className="grid grid-cols-3 gap-6">
        <LeaderStat icon={<Medal className="text-slate-400" />} label="Avg Quizzes" value="12+" />
        <LeaderStat icon={<Trophy className="text-blue-500" />} label="Global Players" value="5,000+" />
        <LeaderStat icon={<Crown className="text-amber-500" />} label="High Score" value={leaders[0]?.totalScore.toLocaleString() || '0'} />
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-[#F3F4F6] dark:border-slate-800 overflow-hidden shadow-vibrant">
        <div className="p-8 bg-slate-50 dark:bg-slate-800 border-b border-[#F3F4F6] dark:border-slate-800 flex justify-between items-center">
           <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center space-x-2">
             <Trophy className="w-6 h-6 text-blue-600" />
             <span>Top Rankings</span>
           </h3>
           <span className="text-xs font-bold uppercase text-slate-400 tracking-widest">Update: Real-time</span>
        </div>
        
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {leaders.map((leader, i) => (
            <div key={leader.id} className="group flex items-center p-6 hover:bg-[#EFF6FF] dark:hover:bg-slate-800/50 transition-colors">
              <div className="w-12 text-center text-xl font-black text-blue-600/20 group-hover:text-blue-600 transition-colors">
                {i + 1}
              </div>
              
              <div className="flex-1 flex items-center space-x-4">
                <div className="w-12 h-12 bg-white dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-blue-600 dark:text-indigo-400 font-bold text-lg border border-[#F3F4F6] dark:border-indigo-800 shadow-sm">
                   {leader.displayName[0] || 'U'}
                </div>
                <div>
                   <h4 className="font-bold text-slate-800 dark:text-white leading-tight">{leader.displayName}</h4>
                   <p className="text-[10px] uppercase font-black tracking-widest text-slate-400 mt-0.5">Chemistry Scholar</p>
                </div>
              </div>

              <div className="text-right">
                 <div className="text-lg font-black text-slate-900 dark:text-white">{leader.totalScore.toLocaleString()}</div>
                 <div className="flex items-center justify-end text-[10px] text-emerald-500 font-bold uppercase tracking-widest">
                   <ArrowUp className="w-3 h-3 mr-1" />
                   <span>XP Points</span>
                 </div>
              </div>
            </div>
          ))}

          {leaders.length === 0 && (
            <div className="p-12 text-center text-slate-400">
               No rankings available yet. Be the first to score!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function LeaderStat({ icon, label, value }: any) {
  return (
    <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center text-center space-y-2">
      <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl mb-2">{icon}</div>
      <div className="text-xs uppercase font-black text-slate-400 tracking-widest">{label}</div>
      <div className="text-xl font-black text-slate-900 dark:text-white">{value}</div>
    </div>
  );
}
