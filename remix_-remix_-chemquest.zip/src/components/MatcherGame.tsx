import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Boxes, 
  Timer, 
  Trophy, 
  ChevronLeft, 
  Flame, 
  RotateCcw, 
  Zap,
  CheckCircle2,
  XCircle
} from 'lucide-react';

interface MatcherGameProps {
  user: any;
  onBack: () => void;
}

const GROUPS = [
  { name: 'Alcohol', suffix: '-ol', structure: 'R-OH' },
  { name: 'Ketone', suffix: '-one', structure: 'R-CO-R' },
  { name: 'Aldehyde', suffix: '-al', structure: 'R-CHO' },
  { name: 'Carboxylic Acid', suffix: '-oic acid', structure: 'R-COOH' },
  { name: 'Ester', suffix: '-oate', structure: 'R-COO-R' },
  { name: 'Ether', suffix: '-oxy-', structure: 'R-O-R' },
  { name: 'Amine', suffix: '-amine', structure: 'R-NH2' },
  { name: 'Amide', suffix: '-amide', structure: 'R-CONH2' },
  { name: 'Alkyne', suffix: '-yne', structure: 'R-C≡C-R' },
  { name: 'Alkene', suffix: '-ene', structure: 'R-C=C-R' },
];

export function MatcherGame({ user, onBack }: MatcherGameProps) {
  const [gameState, setGameState] = useState<'lobby' | 'playing' | 'results'>('lobby');
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [options, setOptions] = useState<any[]>([]);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [multiplier, setMultiplier] = useState(1);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  const nextQuestion = useCallback(() => {
    const correct = GROUPS[Math.floor(Math.random() * GROUPS.length)];
    const others = GROUPS.filter(g => g.name !== correct.name)
      .sort(() => 0.5 - Math.random())
      .slice(0, 3);
    
    const allOptions = [...others, correct].sort(() => 0.5 - Math.random());
    
    setCurrentQuestion(correct);
    setOptions(allOptions);
    setFeedback(null);
  }, []);

  const startGame = () => {
    setScore(0);
    setTimeLeft(60);
    setMultiplier(1);
    setGameState('playing');
    nextQuestion();
  };

  const handleAnswer = (selected: any) => {
    if (selected.name === currentQuestion.name) {
      setScore(s => s + (10 * multiplier));
      setMultiplier(m => Math.min(m + 0.1, 3));
      setFeedback('correct');
      setTimeout(nextQuestion, 400);
    } else {
      setMultiplier(1);
      setFeedback('wrong');
      setTimeout(nextQuestion, 600);
    }
  };

  useEffect(() => {
    let timer: any;
    if (gameState === 'playing') {
      timer = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            setGameState('results');
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameState]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={onBack}
            className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:text-pink-600 transition shadow-sm"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white flex items-center space-x-2">
              <Boxes className="w-8 h-8 text-pink-600" />
              <span>Ketone Crush</span>
            </h2>
          </div>
        </div>

        {gameState === 'playing' && (
          <div className="flex items-center space-x-6">
             <div className="bg-pink-100 dark:bg-pink-900/30 px-6 py-2 rounded-2xl border border-pink-200 dark:border-pink-800 shadow-sm">
               <div className="text-[10px] font-black text-pink-600 uppercase tracking-widest leading-none mb-1">Time Left</div>
               <div className="text-2xl font-mono font-black text-pink-700 dark:text-pink-400">
                 00:{timeLeft.toString().padStart(2, '0')}
               </div>
             </div>
             <div className="bg-indigo-600 px-6 py-2 rounded-2xl shadow-lg border border-indigo-500">
               <div className="text-[10px] font-black text-indigo-200 uppercase tracking-widest leading-none mb-1">Total Score</div>
               <div className="text-2xl font-black text-white">{Math.floor(score)}</div>
             </div>
          </div>
        )}
      </div>

      <AnimatePresence mode="wait">
        {gameState === 'lobby' && (
          <motion.div
            key="lobby"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white dark:bg-slate-900 p-12 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-8"
          >
            <div className="w-24 h-24 bg-pink-100 dark:bg-pink-900/40 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-inner relative overflow-hidden group">
               <Boxes className="w-12 h-12 text-pink-600 group-hover:scale-110 transition-transform" />
               <div className="absolute inset-0 bg-gradient-to-tr from-pink-500/10 to-transparent"></div>
            </div>
            
            <div className="space-y-3">
              <h3 className="text-3xl font-black text-slate-900 dark:text-white">Ready to Crush?</h3>
              <p className="text-slate-500 dark:text-slate-400 max-w-sm mx-auto font-medium">
                Identify the functional group name for the given chemical structure. 
                Keep your streak alive to boost your multiplier!
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
               <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700">
                 <div className="text-2xl font-black text-slate-900 dark:text-white">60s</div>
                 <div className="text-[10px] uppercase font-black text-slate-400 tracking-widest">Time Limit</div>
               </div>
               <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700">
                 <div className="text-2xl font-black text-slate-900 dark:text-white">3.0x</div>
                 <div className="text-[10px] uppercase font-black text-slate-400 tracking-widest">Max Combo</div>
               </div>
            </div>

            <button
               onClick={startGame}
               className="w-full max-w-sm py-5 bg-pink-600 text-white rounded-3xl font-black text-xl shadow-xl shadow-pink-100 dark:shadow-none hover:bg-pink-700 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center space-x-3"
            >
              <Flame className="w-6 h-6" />
              <span>Enter Arena</span>
            </button>
          </motion.div>
        )}

        {gameState === 'playing' && currentQuestion && (
          <motion.div
            key="playing"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-10"
          >
             {/* Question Card */}
             <div className="relative">
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-10 flex items-center space-x-2 bg-slate-900 dark:bg-slate-800 text-white px-6 py-2 rounded-full border border-slate-700 shadow-xl">
                  <Zap className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-sm font-black whitespace-nowrap">COMBO {multiplier.toFixed(1)}x</span>
                </div>
                
                <div className="bg-white dark:bg-slate-900 p-16 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-6 relative overflow-hidden">
                   <div className="absolute inset-0 bg-slate-50/50 dark:bg-slate-800/10 opacity-50"></div>
                   <div className="relative z-10">
                      <p className="text-xs font-black text-pink-500 uppercase tracking-[0.3em] mb-4">Structure Identification</p>
                      <h4 className="text-6xl md:text-8xl font-black text-slate-900 dark:text-white tracking-widest font-mono">
                        {currentQuestion.structure}
                      </h4>
                   </div>
                   
                   {/* Feedback Overlay */}
                   <AnimatePresence>
                     {feedback && (
                       <motion.div
                         initial={{ opacity: 0, scale: 0.5 }}
                         animate={{ opacity: 1, scale: 1 }}
                         exit={{ opacity: 0 }}
                         className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none"
                       >
                         {feedback === 'correct' ? (
                           <CheckCircle2 className="w-32 h-32 text-emerald-500/80" />
                         ) : (
                           <XCircle className="w-32 h-32 text-red-500/80" />
                         )}
                       </motion.div>
                     )}
                   </AnimatePresence>
                </div>
             </div>

             {/* Options Grid */}
             <div className="grid grid-cols-2 gap-4">
                {options.map((opt, i) => (
                  <motion.button
                    key={`${opt.name}-${i}`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswer(opt)}
                    className="group bg-white dark:bg-slate-900 border-2 border-slate-100 dark:border-slate-800 p-8 rounded-3xl text-center hover:border-pink-500 hover:bg-pink-50 dark:hover:bg-pink-900/20 transition-all shadow-sm shadow-slate-100 dark:shadow-none"
                  >
                    <span className="text-2xl font-black text-slate-800 dark:text-slate-200 group-hover:text-pink-600 dark:group-hover:text-pink-400">
                      {opt.name}
                    </span>
                  </motion.button>
                ))}
             </div>
          </motion.div>
        )}

        {gameState === 'results' && (
          <motion.div
            key="results"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-slate-900 p-12 rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-2xl text-center space-y-8"
          >
            <div className="relative inline-block">
              <div className="w-32 h-32 bg-pink-600 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl shadow-pink-200">
                <Trophy className="w-16 h-16 text-white" />
              </div>
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3 }}
                className="absolute -top-2 -right-2 bg-yellow-400 text-slate-900 w-12 h-12 rounded-full flex items-center justify-center font-black text-xl border-4 border-white shadow-lg"
              >
                ★
              </motion.div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-4xl font-black text-slate-900 dark:text-white">Session Ended!</h2>
              <p className="text-slate-500 font-medium">You crushed those functional groups!</p>
            </div>

            <div className="p-8 bg-slate-50 dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 max-w-sm mx-auto">
              <div className="text-5xl font-black text-pink-600 dark:text-pink-400 mb-1">{Math.floor(score)}</div>
              <div className="text-xs uppercase tracking-widest font-black text-slate-400">Final Points Earned</div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={startGame}
                className="px-10 py-5 bg-pink-600 text-white rounded-2xl font-black flex items-center justify-center space-x-2 hover:bg-pink-700 transition shadow-xl shadow-pink-100 dark:shadow-none"
              >
                <RotateCcw className="w-5 h-5" />
                <span>Play Again</span>
              </button>
              <button
                onClick={onBack}
                className="px-10 py-5 bg-white dark:bg-slate-800 text-slate-700 dark:text-white border border-slate-200 dark:border-slate-700 rounded-2xl font-black flex items-center justify-center space-x-2 hover:bg-slate-50 dark:hover:bg-slate-700 transition"
              >
                <span>Back to Games</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
