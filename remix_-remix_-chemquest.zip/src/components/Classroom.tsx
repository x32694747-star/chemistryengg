import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, Presentation, UserPlus, ArrowLeft, Play, LayoutDashboard, CheckCircle2, User, Timer } from 'lucide-react';
import io from 'socket.io-client';
import quizData from '../data/quizzes.json';

interface ClassroomProps {
  user: any;
}

export function Classroom({ user }: ClassroomProps) {
  const [socket, setSocket] = useState<any>(null);
  const [mode, setMode] = useState<'selection' | 'teacher-setup' | 'student-join' | 'session'>('selection');
  const [roomCode, setRoomCode] = useState('');
  const [roomData, setRoomData] = useState<any>(null);
  const [error, setError] = useState('');
  const [isTeacher, setIsTeacher] = useState(false);
  const [studentName, setStudentName] = useState(user?.displayName || '');
  const [currentQuestion, setCurrentQuestion] = useState(0);

  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    newSocket.on('room-created', (data) => {
      setRoomData(data);
      setMode('session');
      setIsTeacher(true);
    });

    newSocket.on('joined-room', (data) => {
      setRoomData(data);
      setMode('session');
      setIsTeacher(false);
    });

    newSocket.on('user-joined', (data) => {
      setRoomData((prev: any) => ({ ...prev, students: data.students }));
    });

    newSocket.on('exam-started', (data) => {
      setRoomData(data.room);
    });

    newSocket.on('update-progress', (data) => {
      setRoomData((prev: any) => ({ ...prev, students: data.students }));
    });

    newSocket.on('exam-ended', (data) => {
      setRoomData(data.room);
    });

    newSocket.on('error', (data) => {
      setError(data.message);
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const handleCreateRoom = (quiz: any) => {
    if (!socket) return;
    socket.emit('create-room', {
      teacherName: user?.displayName || 'Teacher',
      quizId: quiz.id,
      quizTitle: quiz.title || quiz.topic
    });
  };

  const handleJoinRoom = () => {
    if (!socket || !roomCode) return;
    socket.emit('join-room', {
      roomCode: roomCode.trim().toUpperCase(),
      studentName: studentName || 'Anonymous Student'
    });
  };

  const handleStartExam = () => {
    if (!socket || !roomData) return;
    socket.emit('start-exam', roomData.id);
  };

  const handleEndExam = () => {
    if (!socket || !roomData) return;
    socket.emit('end-exam', roomData.id);
  };

  const handleSubmitAnswer = (answerIndex: number) => {
    if (!socket || !roomData) return;
    
    // Get full quiz data for the current quiz
    const fullQuiz = quizData.filter(q => q.topic === roomData.quizTitle || q.difficulty === roomData.quizTitle);
    // Note: roomData.quizId is used but our data is a flat list. 
    // In a real app we'd have unique IDs. Let's just find matching questions.
    const questions = quizData.slice(0, 5); // Fallback: just use first 5 for now
    
    const isCorrect = answerIndex === questions[currentQuestion].answer;
    
    socket.emit('submit-answer', {
      roomCode: roomData.id,
      questionIndex: currentQuestion,
      answer: answerIndex,
      isCorrect
    });

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // Finished
      setCurrentQuestion(-1); 
    }
  };

  if (mode === 'session' && roomData) {
    const questions = quizData.slice(0, 5); // Use first 5 for demo

    if (isTeacher) {
      return (
        <div className="max-w-6xl mx-auto space-y-8">
           <div className="flex justify-between items-center bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
             <div>
               <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Classroom: {roomData.id}</h2>
               <p className="text-slate-500">{roomData.quizTitle}</p>
             </div>
             <div className="flex items-center space-x-4">
                {roomData.status === 'waiting' && (
                  <button 
                    onClick={handleStartExam}
                    className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-xl font-bold transition shadow-lg"
                  >
                    <Play className="w-5 h-5" />
                    <span>Start Exam</span>
                  </button>
                )}
                {roomData.status === 'active' && (
                  <button 
                    onClick={handleEndExam}
                    className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-bold transition shadow-lg"
                  >
                    <span>End Exam</span>
                  </button>
                )}
             </div>
           </div>

           <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-6">
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
                  <h3 className="text-xl font-bold text-slate-800 dark:text-white mb-6 flex items-center space-x-2">
                    <LayoutDashboard className="w-6 h-6 text-blue-600" />
                    <span>Live Progress Monitor</span>
                  </h3>
                  
                  <div className="space-y-6">
                    {roomData.students.length === 0 ? (
                       <div className="text-center py-12 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-slate-400 font-medium">
                         Waiting for students to join...
                       </div>
                    ) : (
                      roomData.students.map((student: any) => (
                        <div key={student.id} className="space-y-2">
                          <div className="flex justify-between items-center text-sm">
                            <div className="flex items-center space-x-2">
                              <User className="w-4 h-4 text-slate-400" />
                              <span className="font-bold text-slate-700 dark:text-slate-200">{student.name}</span>
                            </div>
                            <span className="font-mono bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded text-xs">
                              Score: {student.score}
                            </span>
                          </div>
                          <div className="bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden flex">
                            {questions.map((_, i) => {
                              const ans = student.answers[i];
                              return (
                                <div 
                                  key={i} 
                                  className={`flex-1 h-full border-r border-white dark:border-slate-900 last:border-0 transition-colors ${
                                    !ans ? 'bg-slate-200 dark:bg-slate-700' : ans.isCorrect ? 'bg-emerald-500' : 'bg-red-500'
                                  }`}
                                />
                              );
                            })}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-2xl text-white shadow-xl relative overflow-hidden">
                   <Users className="absolute -right-4 -bottom-4 w-32 h-32 opacity-10" />
                   <h3 className="text-lg font-bold mb-4">Classroom Info</h3>
                   <div className="space-y-4 text-sm">
                      <div className="flex justify-between items-center border-b border-white/20 pb-2">
                        <span className="opacity-70">Room Code</span>
                        <span className="font-mono font-black text-xl tracking-widest">{roomData.id}</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-white/20 pb-2">
                        <span className="opacity-70">Students Joined</span>
                        <span className="font-bold">{roomData.students.length}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="opacity-70">Status</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          roomData.status === 'waiting' ? 'bg-amber-400 text-amber-900' : 
                          roomData.status === 'active' ? 'bg-emerald-400 text-emerald-900' : 'bg-slate-400 text-white'
                        }`}>
                          {roomData.status}
                        </span>
                      </div>
                   </div>
                </div>
              </div>
           </div>
        </div>
      );
    }

    // Student view
    return (
      <div className="max-w-3xl mx-auto py-8">
        <AnimatePresence mode="wait">
          {roomData.status === 'waiting' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center space-y-8 bg-white dark:bg-slate-900 p-12 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl">
              <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <Timer className="w-12 h-12 text-blue-600 animate-pulse" />
              </div>
              <h2 className="text-3xl font-black text-slate-800 dark:text-white">Waiting for Teacher</h2>
              <p className="text-slate-500 max-w-md mx-auto">
                You've joined room <span className="font-mono font-bold text-blue-600">{roomData.id}</span>. 
                Please wait for your teacher to initiate the exam.
              </p>
              <div className="flex items-center justify-center space-x-2 text-slate-400 text-sm italic">
                <Presentation className="w-4 h-4" />
                <span>Hosting: {roomData.teacherName}</span>
              </div>
            </motion.div>
          )}

          {roomData.status === 'active' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8">
              {currentQuestion === -1 ? (
                <div className="text-center space-y-6 bg-white dark:bg-slate-900 p-12 rounded-[2.5rem] shadow-xl border border-slate-200 dark:border-slate-800">
                  <CheckCircle2 className="w-20 h-20 text-emerald-500 mx-auto" />
                  <h2 className="text-3xl font-black text-slate-800 dark:text-white">All Done!</h2>
                  <p className="text-slate-500">Your answers have been submitted. Wait for the teacher to end the session to see final results.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="flex justify-between items-center text-sm font-bold text-slate-500">
                    <span>Classroom Quiz</span>
                    <span>Question {currentQuestion + 1} / {questions.length}</span>
                  </div>
                  <div className="bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl space-y-10">
                    <h3 className="text-2xl font-bold text-slate-800 dark:text-white">{questions[currentQuestion].question}</h3>
                    <div className="grid gap-4">
                      {questions[currentQuestion].options.map((opt: string, i: number) => (
                        <button
                          key={i}
                          onClick={() => handleSubmitAnswer(i)}
                          className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 text-left font-bold text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:border-blue-500 transition-all hover:scale-[1.01] active:scale-[0.99]"
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {roomData.status === 'finished' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center space-y-8 bg-white dark:bg-slate-900 p-12 rounded-[2.5rem] shadow-xl border border-slate-200 dark:border-slate-800">
               <h2 className="text-3xl font-black text-slate-800 dark:text-white">Exam Finished</h2>
               <div className="max-w-sm mx-auto p-8 bg-blue-50 dark:bg-blue-900/20 rounded-3xl border border-blue-100 dark:border-blue-900/40">
                 <div className="text-sm font-bold text-blue-400 uppercase tracking-widest mb-1">Your Total Score</div>
                 <div className="text-6xl font-black text-blue-600">
                    {roomData.students.find((s: any) => s.id === socket?.id)?.score || 0}
                 </div>
               </div>
               <p className="text-slate-500">Great effort! You can see how others performed on the teacher's screen.</p>
               <button onClick={() => setMode('selection')} className="text-blue-600 font-bold hover:underline">Back to Selection</button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-12 px-4 space-y-12">
      <div className="text-center space-y-4">
        <motion.div 
          initial={{ scale: 0.8 }} 
          animate={{ scale: 1 }}
          className="mx-auto w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg transform -rotate-6"
        >
          <Presentation className="w-8 h-8" />
        </motion.div>
        <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Live Classroom</h1>
        <p className="text-slate-500 max-w-xl mx-auto">Host live competitive exams with real-time feedback for your entire class.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <motion.div 
          whileHover={{ y: -5 }}
          className="glass-card p-10 rounded-[2.5rem] border-2 border-transparent hover:border-blue-500 transition-all group"
        >
          <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
            <UserPlus className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">Join as Student</h2>
          <p className="text-slate-500 mb-8">Enter the unique code provided by your teacher to join the live session.</p>
          
          <div className="space-y-4">
            {!user && (
              <input 
                type="text" 
                placeholder="Your Name"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-blue-500 outline-none font-bold"
              />
            )}
            <input 
              type="text" 
              placeholder="Enter Room Code (e.g. AB12XY)"
              value={roomCode}
              onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
              className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 focus:ring-2 focus:ring-blue-500 outline-none font-mono font-bold text-center tracking-widest uppercase"
            />
            <button 
              onClick={handleJoinRoom}
              disabled={!roomCode}
              className="w-full py-4 bg-blue-600 disabled:opacity-50 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition shadow-vibrant"
            >
              Join Session
            </button>
          </div>
          {error && <p className="text-red-500 mt-4 text-center font-medium animate-shake">{error}</p>}
        </motion.div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="glass-card p-10 rounded-[2.5rem] border-2 border-transparent hover:border-indigo-500 transition-all group"
        >
          <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
            <Presentation className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">Host as Teacher</h2>
          <p className="text-slate-500 mb-8">Pick a quiz from the list below and create a live classroom session.</p>
          
          <div className="space-y-3 max-h-[280px] overflow-y-auto pr-2 custom-scrollbar">
             {/* Filter unique topics to show as potential quizzes */}
             {Array.from(new Set(quizData.map(q => q.topic))).map((topic, i) => (
                <button
                  key={i}
                  onClick={() => handleCreateRoom({ id: i, topic })}
                  className="w-full flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-left hover:border-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-700 transition group"
                >
                  <span className="font-bold text-slate-700 dark:text-slate-200">{topic}</span>
                  <Play className="w-4 h-4 text-slate-300 group-hover:text-indigo-600 transition-colors" />
                </button>
             ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
