import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Timer, ArrowRight, CheckCircle2, XCircle, Trophy, RotateCcw, Filter, Flame, Loader2 } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, updateStats, handleFirestoreError } from '../lib/firebase';
import quizData from '../data/quizzes.json';

interface QuizProps {
  user: any;
}

export function Quiz({ user }: QuizProps) {
  const [gameState, setGameState] = useState<'lobby' | 'playing' | 'results'>('lobby');
  const [currentTopic, setCurrentTopic] = useState<string>('All');
  const [currentDifficulty, setCurrentDifficulty] = useState<string>('All');
  const [questions, setQuestions] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [answers, setAnswers] = useState<any[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const topics = ['All', 'Water Technology', 'Green Chemistry', 'Physical Chemistry', 'Organic Chemistry', 'Inorganic Chemistry'];
  const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  const startQuiz = (topic: string, difficulty: string) => {
    let filtered = quizData;
    if (topic !== 'All') filtered = filtered.filter(q => q.topic === topic);
    if (difficulty !== 'All') filtered = filtered.filter(q => q.difficulty === difficulty);
    
    // Shuffle and pick top 5
    const shuffled = [...filtered].sort(() => 0.5 - Math.random()).slice(0, 5);
    
    if (shuffled.length === 0) {
      alert("No questions found for this combination. Try a different filter!");
      return;
    }

    setQuestions(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setAnswers([]);
    setTimeLeft(30);
    setGameState('playing');
  };

  const handleAnswer = useCallback(async (optionIndex: number | null) => {
    const isCorrect = optionIndex === questions[currentIndex].answer;
    const points = isCorrect ? 10 : 0;
    
    setAnswers(prev => [...prev, {
      question: questions[currentIndex].question,
      selected: optionIndex,
      correct: questions[currentIndex].answer,
      isCorrect
    }]);

    if (currentIndex < questions.length - 1) {
      if (isCorrect) setScore(s => s + points);
      setCurrentIndex(currentIndex + 1);
      setTimeLeft(30);
    } else {
      const finalScore = score + points;
      setScore(finalScore);
      setGameState('results');
      
      if (user) {
        setIsSaving(true);
        try {
          const resultData = {
            userId: user.uid,
            topic: currentTopic,
            difficulty: currentDifficulty,
            score: finalScore,
            totalQuestions: questions.length,
            timeSpent: 0,
            completedAt: serverTimestamp()
          };
          
          await addDoc(collection(db, 'users', user.uid, 'quizResults'), resultData)
            .catch(e => handleFirestoreError(e, 'create', `users/${user.uid}/quizResults`));
          
          await updateStats(user.uid, finalScore, true);
        } catch (err) {
          console.error("Failed to save results:", err);
        } finally {
          setIsSaving(false);
        }
      }
    }
  }, [currentIndex, questions, user, currentTopic, currentDifficulty, score]);

  useEffect(() => {
    let timer: any;
    if (gameState === 'playing') {
      timer = setInterval(() => {
        setTimeLeft(t => {
          if (t <= 1) {
            handleAnswer(null); // Timeout answer
            return 30;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameState, handleAnswer]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-6">
      {gameState === 'lobby' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-slate-900">Chemistry Quiz Arena</h2>
            <p className="text-slate-600">Choose a topic and difficulty level to begin your challenge.</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="glass-card p-8 rounded-2xl space-y-6">
              <div className="flex items-center space-x-2 text-blue-600 dark:text-blue-400 font-bold mb-2">
                <Filter className="w-5 h-5" />
                <span>Filters</span>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Subject Topic</label>
                  <div className="grid grid-cols-2 gap-2">
                    {topics.map(t => (
                      <button
                        key={t}
                        onClick={() => setCurrentTopic(t)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          currentTopic === t ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-[#EFF6FF] dark:hover:bg-slate-700'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Difficulty Level</label>
                  <div className="flex flex-wrap gap-2">
                    {difficulties.map(d => (
                      <button
                        key={d}
                        onClick={() => setCurrentDifficulty(d)}
                        className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                          currentDifficulty === d ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-[#EFF6FF] dark:hover:bg-slate-700'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => startQuiz(currentTopic, currentDifficulty)}
                className="w-full mt-6 py-4 bg-blue-600 text-white rounded-xl font-bold text-lg hover:bg-blue-700 transition shadow-vibrant flex items-center justify-center space-x-2"
              >
                <Flame className="w-5 h-5" />
                <span>Start Quiz</span>
              </button>
            </div>

            <div className="bg-gradient-to-br from-blue-600 to-blue-500 p-8 rounded-2xl text-white space-y-6 shadow-vibrant relative overflow-hidden">
               <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
               <h3 className="text-2xl font-bold flex items-center space-x-2">
                 <Trophy className="w-6 h-6 text-yellow-400" />
                 <span>Leaderboard Ready?</span>
               </h3>
               <p className="text-blue-50 opacity-90 leading-relaxed font-medium">
                 Earn points by answering correctly and quickly. Your top score will be saved and displayed on the global leaderboard.
               </p>
               <div className="space-y-4 pt-4">
                 <div className="bg-white/10 p-4 rounded-xl flex justify-between items-center border border-white/10">
                   <span className="text-sm font-medium">Total Questions</span>
                   <span className="font-bold">5 per round</span>
                 </div>
                 <div className="bg-white/10 p-4 rounded-xl flex justify-between items-center border border-white/10">
                   <span className="text-sm font-medium">Time per Question</span>
                   <span className="font-bold">30 seconds</span>
                 </div>
               </div>
            </div>
          </div>
        </motion.div>
      )}

      {gameState === 'playing' && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8">
          <div className="flex justify-between items-center px-4">
            <div className="flex items-center space-x-4">
              <div className="bg-white dark:bg-slate-800 px-4 py-2 rounded-full border border-slate-200 dark:border-slate-700 text-sm font-bold shadow-sm dark:text-white">
                Question {currentIndex + 1} / {questions.length}
              </div>
              <div className="text-slate-500 dark:text-slate-400 font-medium text-sm">{questions[currentIndex].topic}</div>
            </div>
            <div className={`flex items-center space-x-2 px-6 py-2 rounded-full font-mono font-bold text-lg shadow-md transition-colors ${
              timeLeft <= 5 ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 animate-pulse' : 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200 dark:border-slate-700'
            }`}>
              <Timer className="w-5 h-5" />
              <span>00:{timeLeft.toString().padStart(2, '0')}</span>
            </div>
          </div>

          <div className="glass-card p-8 md:p-12 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-xl space-y-10">
            <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white leading-tight">
              {questions[currentIndex].question}
            </h3>

            <div className="grid gap-4">
              {questions[currentIndex].options.map((option: string, i: number) => (
                <button
                  key={i}
                  onClick={() => handleAnswer(i)}
                  className="group relative overflow-hidden bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 p-6 rounded-2xl text-left font-semibold text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:border-blue-200 dark:hover:border-blue-800 hover:text-blue-700 dark:hover:text-blue-400 transition-all active:scale-[0.98]"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 group-hover:bg-blue-200 dark:group-hover:bg-blue-900/40 group-hover:text-blue-600 dark:group-hover:text-blue-300 transition-colors">
                      {String.fromCharCode(65 + i)}
                    </div>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Progress bar */}
          <div className="bg-slate-200 h-2 rounded-full overflow-hidden">
            <motion.div 
               className="bg-blue-600 h-full"
               initial={{ width: 0 }}
               animate={{ width: `${((currentIndex) / questions.length) * 100}%` }}
            />
          </div>
        </motion.div>
      )}

      {gameState === 'results' && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
          <div className="glass-card p-12 rounded-[3rem] text-center space-y-8">
            <div className="relative inline-block">
              <div className="w-32 h-32 bg-blue-600 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-blue-200">
                <Trophy className="w-16 h-16 text-white" />
              </div>
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3 }}
                className="absolute -top-2 -right-2 bg-yellow-400 text-slate-900 w-12 h-12 rounded-full flex items-center justify-center font-black text-xl border-4 border-white shadow-lg"
              >
                ★
              </motion.div>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-4xl font-extrabold text-slate-900 dark:text-white">Quiz Completed!</h2>
              <p className="text-slate-500 dark:text-slate-400 font-medium">
                {isSaving ? 'Saving your score to the leaderboard...' : "Great job! Here's how you performed today."}
              </p>
              {isSaving && <Loader2 className="w-6 h-6 animate-spin mx-auto text-blue-600 mt-2" />}
            </div>

            <div className="grid grid-cols-3 gap-6 max-w-lg mx-auto">
              <div className="p-6 rounded-2.5xl bg-blue-50 border border-blue-100">
                <div className="text-3xl font-black text-blue-600">{score}</div>
                <div className="text-xs uppercase tracking-widest font-bold text-blue-400">Points</div>
              </div>
              <div className="p-6 rounded-2.5xl bg-emerald-50 border border-emerald-100">
                <div className="text-3xl font-black text-emerald-600">{answers.filter(a => a.isCorrect).length}</div>
                <div className="text-xs uppercase tracking-widest font-bold text-emerald-400">Correct</div>
              </div>
              <div className="p-6 rounded-2.5xl bg-amber-50 border border-amber-100">
                <div className="text-3xl font-black text-amber-600">{(score / (questions.length * 10) * 100).toFixed(0)}%</div>
                <div className="text-xs uppercase tracking-widest font-bold text-amber-400">Accuracy</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => setGameState('lobby')}
                className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-bold flex items-center justify-center space-x-2 hover:bg-blue-700 transition transform hover:-translate-y-1 shadow-xl shadow-blue-100"
              >
                <RotateCcw className="w-5 h-5" />
                <span>Try Again</span>
              </button>
              <button
                onClick={() => setGameState('lobby')}
                className="px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-2xl font-bold flex items-center justify-center space-x-2 hover:bg-slate-50 transition"
              >
                <span>Choose Another Quiz</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Detailed Breakdown */}
          <div className="space-y-6">
            <h4 className="text-xl font-bold text-slate-900 px-4">Question Breakdown</h4>
            <div className="space-y-4">
              {answers.map((ans, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 flex items-start space-x-4">
                  {ans.isCorrect ? (
                    <CheckCircle2 className="w-6 h-6 text-emerald-500 flex-shrink-0 mt-1" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-1" />
                  )}
                  <div className="space-y-2">
                    <p className="font-semibold text-slate-800">{ans.question}</p>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="bg-slate-100 px-3 py-1 rounded-full text-slate-600">
                        Your answer: <span className={ans.isCorrect ? 'text-emerald-600 font-bold' : 'text-red-600 font-bold'}>
                          {ans.selected === null ? 'Timed Out' : questions[i].options[ans.selected]}
                        </span>
                      </div>
                      {!ans.isCorrect && (
                        <div className="bg-emerald-50 px-3 py-1 rounded-full text-emerald-700">
                          Correct: <span className="font-bold">{questions[i].options[ans.correct]}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
