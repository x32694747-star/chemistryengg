import React, { useState } from 'react';
import { BookOpen, Download, FileText, Search, ExternalLink, Bookmark, Hash } from 'lucide-react';

export function Notes() {
  const [searchTerm, setSearchTerm] = useState('');

  const notes = [
    {
      id: 'n4',
      topic: 'Water Technology',
      title: 'Zeolite & Ion Exchange',
      description: 'Comparison of modern water softening methods and regeneration processes.',
      keywords: ['Hardness', 'Regeneration', 'Permutit']
    },
    {
      id: 'n5',
      topic: 'Green Chemistry',
      title: 'The 12 Principles',
      description: 'Full explanation of the twelve principles with real-world examples.',
      keywords: ['Atom Economy', 'Sustainability', 'Effluent']
    },
    {
      id: 'n6',
      topic: 'Physical Chemistry',
      title: 'Thermodynamics & Kinetics',
      description: 'Summary of the laws of thermodynamics and rate of chemical reactions.',
      keywords: ['Enthalpy', 'Entropy', 'Activation Energy']
    },
    {
      id: 'n7',
      topic: 'Organic Chemistry',
      title: 'Nomenclature & Groups',
      description: 'Guide to IUPAC naming conventions and essential functional groups.',
      keywords: ['IUPAC', 'Isomerism', 'Hybridization']
    },
    {
      id: 'n8',
      topic: 'Inorganic Chemistry',
      title: 'Periodic Trends & Bonding',
      description: 'Deep dive into electronegativity, ionization energy, and chemical bonding types.',
      keywords: ['VSEPR', 'Electronegativity', 'Oxidation']
    }
  ];

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    n.topic.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDownload = (title: string) => {
    alert(`Starting download for: ${title}.pdf\n(Note: This is a simulation)`);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12 py-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <h2 className="text-4xl font-bold text-slate-900 leading-tight">Revision Notes Hub</h2>
          <p className="text-slate-600 max-w-xl">
            Access concise, high-quality notes compiled for quick revision before exams.
          </p>
        </div>
        <div className="relative w-full md:w-96">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search topics or keywords..." 
            className="w-full bg-white dark:bg-slate-900 border border-[#F3F4F6] dark:border-slate-800 rounded-2xl py-4 pl-12 pr-6 outline-none focus:border-blue-500 shadow-vibrant transition-all dark:text-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <div key={note.id} className="group glass-card rounded-2xl transition-all duration-300 p-8 flex flex-col h-full hover:border-blue-200 dark:hover:border-blue-900 shadow-xl">
            <div className="flex justify-between items-start mb-6">
              <div className="bg-blue-50 dark:bg-blue-900/30 p-3 rounded-xl text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <FileText className="w-8 h-8" />
              </div>
              <span className="bg-[#DBEAFE] text-[#1E40AF] text-[10px] uppercase font-black tracking-widest px-3 py-1 rounded-full border border-blue-200">
                {note.topic}
              </span>
            </div>
            
            <div className="flex-1 space-y-4 mb-8">
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white leading-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {note.title}
              </h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed line-clamp-3">
                {note.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {note.keywords.map((k, i) => (
                  <span key={i} className="text-[10px] font-bold text-slate-400 dark:text-slate-500 flex items-center space-x-1">
                    <Hash className="w-3 h-3" />
                    <span>{k}</span>
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-6 border-t border-slate-50 dark:border-slate-800">
              <button 
                onClick={() => handleDownload(note.title)}
                className="flex-1 flex items-center justify-center space-x-2 bg-slate-900 dark:bg-blue-600 text-white rounded-xl py-3 text-sm font-bold hover:bg-slate-800 dark:hover:bg-blue-700 transition"
              >
                <Download className="w-4 h-4" />
                <span>PDF Guide</span>
              </button>
              <button className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition">
                <Bookmark className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}

        {/* Placeholder for "Coming Soon" */}
        <div className="bg-slate-50 dark:bg-slate-900/50 rounded-[2rem] border-2 border-dashed border-slate-200 dark:border-slate-800 p-8 flex flex-col items-center justify-center text-center space-y-4">
           <div className="bg-white dark:bg-slate-900 p-4 rounded-full shadow-sm">
             <BookOpen className="w-8 h-8 text-slate-300 dark:text-slate-700" />
           </div>
           <div>
             <h4 className="font-bold text-slate-400 dark:text-slate-600">More Topics Soon</h4>
             <p className="text-slate-400 dark:text-slate-600 text-xs mt-1">We're updating our library weekly with new formulas and cheat sheets.</p>
           </div>
        </div>
      </div>
    </div>
  );
}
