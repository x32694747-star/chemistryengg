/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, ensureUserProfile } from './lib/firebase';
import { Navbar } from './components/Navbar';
import { Home } from './components/Home';
import { Quiz } from './components/Quiz';
import { Problems } from './components/Problems';
import { Notes } from './components/Notes';
import { About } from './components/About';
import { Auth } from './components/Auth';
import { Leaderboard } from './components/Leaderboard';
import { Games } from './components/Games';
import { MatcherGame } from './components/MatcherGame';
import { ReactionPredictor } from './components/ReactionPredictor';
import { MemoryGame } from './components/MemoryGame';
import { Classroom } from './components/Classroom';

export type View = 'home' | 'quizzes' | 'problems' | 'notes' | 'about' | 'auth' | 'leaderboard' | 'games' | 'matcher' | 'predictor' | 'memory' | 'classroom';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      if (u) {
        await ensureUserProfile(u);
        setUser(u);
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-bold animate-pulse">Initializing ChemQuest...</p>
        </div>
      </div>
    );
  }

  const renderView = () => {
    switch (currentView) {
      case 'home': return <Home onViewChange={setCurrentView} />;
      case 'quizzes': return <Quiz user={user} />;
      case 'problems': return <Problems user={user} />;
      case 'notes': return <Notes />;
      case 'about': return <About />;
      case 'auth': return <Auth onAuthSuccess={(u: any) => { setUser(u); setCurrentView('home'); }} />;
      case 'leaderboard': return <Leaderboard />;
      case 'games': return <Games onViewChange={setCurrentView} />;
      case 'matcher': return <MatcherGame user={user} onBack={() => setCurrentView('games')} />;
      case 'predictor': return <ReactionPredictor user={user} onBack={() => setCurrentView('games')} />;
      case 'memory': return <MemoryGame user={user} onBack={() => setCurrentView('games')} />;
      case 'classroom': return <Classroom user={user} />;
      default: return <Home onViewChange={setCurrentView} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F0F7FF] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      <Navbar currentView={currentView} onViewChange={setCurrentView} user={user} />
      
      <main className="pt-24 pb-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="container mx-auto px-4"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800 py-8 bg-white dark:bg-slate-900">
        <div className="container mx-auto px-4 text-center text-slate-500 text-sm">
          <p>© 2026 ChemQuest - Educational Chemistry Quiz Hub</p>
          <div className="mt-2 flex justify-center space-x-6">
            <button onClick={() => setCurrentView('about')} className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">About</button>
            <button className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Privacy Policy</button>
            <button className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">Terms of Service</button>
          </div>
        </div>
      </footer>
    </div>
  );
}
