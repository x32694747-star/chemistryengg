import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, query, orderBy, limit, onSnapshot, where, getDocFromServer, serverTimestamp, increment } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

export const isConfigured = firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith('remixed-');

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId); // MUST use firestoreDatabaseId from config
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Connection Test as per instructions
async function testConnection() {
  if (!isConfigured) {
    console.warn("Firebase is not configured. Running in offline/demo mode.");
    return;
  }
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    }
  }
}
testConnection();

// Error handler as per instructions
export interface FirestoreErrorInfo {
  error: string;
  operationType: 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
  path: string | null;
  authInfo: {
    userId: string;
    email: string;
    emailVerified: boolean;
    isAnonymous: boolean;
    providerInfo: { providerId: string; displayName: string; email: string; }[];
  }
}

export function handleFirestoreError(error: any, operationType: FirestoreErrorInfo['operationType'], path: string | null = null): never {
  const user = auth.currentUser;
  const errorInfo: FirestoreErrorInfo = {
    error: error.message || 'Unknown Firestore error',
    operationType,
    path,
    authInfo: {
      userId: user?.uid || 'anonymous',
      email: user?.email || '',
      emailVerified: user?.emailVerified || false,
      isAnonymous: user?.isAnonymous || true,
      providerInfo: user?.providerData.map(p => ({
        providerId: p.providerId,
        displayName: p.displayName || '',
        email: p.email || ''
      })) || []
    }
  };
  throw new Error(JSON.stringify(errorInfo));
}

// User Profile Service
export async function ensureUserProfile(user: any) {
  if (!isConfigured) return;
  const userRef = doc(db, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  
  if (!userSnap.exists()) {
    const profile = {
      uid: user.uid,
      displayName: user.displayName || 'Researcher',
      email: user.email,
      totalScore: 0,
      quizzesCompleted: 0,
      problemsSolved: 0,
      lastActive: serverTimestamp()
    };
    await setDoc(userRef, profile).catch(e => handleFirestoreError(e, 'create', `users/${user.uid}`));
    
    // Also add to leaderboard
    await setDoc(doc(db, 'leaderboard', user.uid), {
      displayName: profile.displayName,
      totalScore: 0
    }).catch(e => handleFirestoreError(e, 'create', `leaderboard/${user.uid}`));
  } else {
    await updateDoc(userRef, { lastActive: serverTimestamp() }).catch(e => handleFirestoreError(e, 'update', `users/${user.uid}`));
  }
}

// Stats Update Service
export async function updateStats(userId: string, scoreIncr: number, isQuiz: boolean) {
  if (!isConfigured) return;
  const userRef = doc(db, 'users', userId);
  const updateData: any = {
    totalScore: increment(scoreIncr),
    lastActive: serverTimestamp()
  };
  
  if (isQuiz) {
    updateData.quizzesCompleted = increment(1);
  } else {
    updateData.problemsSolved = increment(1);
  }

  await updateDoc(userRef, updateData).catch(e => handleFirestoreError(e, 'update', `users/${userId}`));
  
  // Update leaderboard record
  await updateDoc(doc(db, 'leaderboard', userId), {
    totalScore: increment(scoreIncr)
  }).catch(e => handleFirestoreError(e, 'update', `leaderboard/${userId}`));
}
